OvarianCancer&SubtypesDatasetHistopathology
Published: 31 March 2021| Version 1 | DOI: 10.17632/kztymsrjx9.1
Contributor: Kokila Kasture

This dataset includes histopathology images of 4 subtypes of Ovarian cancer and also non cancerous histopathological images.

https://data.mendeley.com/datasets/kztymsrjx9/1

Kasture, Kokila (2021), “OvarianCancer&SubtypesDatasetHistopathology”, Mendeley Data, V1, doi: 10.17632/kztymsrjx9.1